# -*- coding: utf-8 -*-
"""
Created on Mon Jul 25 05:49:25 2022

@author: WNZ
"""





import torch
from torch.nn import Linear,Tanh,Sequential,ReLU,Softplus
import torch.nn.functional as F
from torch.autograd import Variable
import torch.utils.data as Data
import torch.nn as nn
import torch.nn.functional as func
import random
from train_func import train_model

torch.manual_seed(100) 


#from pyDOE import lhs
import math
import numpy as np

import matplotlib.pyplot as plt



import matplotlib.gridspec as gridspec


import time
from scipy.interpolate import griddata

import re
import os
import os.path
import operator

import sys

from KLE import eigen_value_solution,sort_lamda,eigen_func
from func_run2_with_pro import run_rel

from MyConvModel import ConvNet5,ConvNet5_hard_elu,ConvNet5_hard_elu_p,\
    ConvNet5_hard_lrelu_p,ConvNet5_hard_lrelu,ConvNet5_hard_swish,\
    ConvNet5_swish
from cnn_lstm import conv_lstm0
plt.rcParams['figure.max_open_warning']=100
plt.rcParams['savefig.dpi'] = 100 #图片像素
plt.rcParams['figure.dpi'] = 100 #分辨率


save_fig=False

if save_fig:
    localtime = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
    
    fig_path='E:\\1_research\\8_TgNN_RSC_singlephase\\2_case_six_well_q\\4_figure_results\\'+\
        '%s'%(localtime)+'\\'
    os.mkdir(fig_path)
#############################################################################################
#############################################################################################
#########################################################################
#设备设置
device = torch.device('cuda:0')
  


##################################
###参数设置
######################################

#渗透率场设置
mean_logk=3
var=0.25
L_x= 1020    #区域长度
L_y= 1020

eta=L_x*0.4      #相关长度

nx=51     #网格个数
ny=51

nz=1
nt=50      #时间步数

domain=L_x*L_y
weight=0.85



dx=20
dy=20
dz=20
dt=1
x=np.arange(1,nx+1,1)
x=x*dx
y=np.arange(1,ny+1,1)
y=y*dy

t=np.linspace(1,nt,nt)


p_init=300
p_boun1_0=350
p_boun2_0=270

s_boun1_0=1
s_boun2_0=0


t_nday=30



pinj0=350
pw0=270


rw=0.1
##############################
###pvt
co=0.00009
rou_o=800
bo0=1.1
vo=0.85

cw=0.00006
vw=0.32
bw0=1
rou_w=1000

cr=0
##############
#地层参数
poro=0.15


k_rw0=0.8
k_ro0=1
s_wr=0.2
s_or=0.2
b=2
a=3


###################################################


n_well_pro=5
n_well_inj=4
#内边界
#井位信息
xp1=10
yp1=10

xp2=40
yp2=10

xp3=25
yp3=25

xp4=10
yp4=40

xp5=40
yp5=40

xp6=25
yp6=10

xp7=10
yp7=25

xp8=40
yp8=25

xp9=25
yp9=40

xp_set=[xp1,xp2,xp3,xp4,xp5,xp6,xp7,xp8,xp9]
yp_set=[yp1,yp2,yp3,yp4,yp5,yp6,yp7,yp8,yp9]




#################################################
###Data Processing
#################################################
# bigx=100
# L_x=L_x/bigx
# L_y= L_y/bigx
# eta=eta/bigx
# domain=L_x*L_y
# x=x/bigx
# y=y/bigx
# Ss=Ss*bigx*bigx
# dx=dx/bigx
# dy=dy/bigx


###########################################
###计算所需特征值个数
#########################################
n_test=50
lamda_x,w_x0,cumulate_lamda_x=eigen_value_solution(eta,L_x,var,n_test)
lamda_y,w_y0,cumulate_lamda_y=eigen_value_solution(eta,L_y,var,n_test)


############################################################
#二维特征值计算，混合，排序，截断
lamda_xy,w_x,w_y,n_eigen,cum_lamda=sort_lamda(lamda_x,w_x0,lamda_y,w_y0,domain,var,weight)

#########################################################
#根据weight获取所需计算特征值个数,并计算特征值以及特征函数值
#################################################
fn_x=[]
fn_y=[]


for i_x in range(nx):
    f_x=eigen_func(n_eigen,w_x,eta,L_x,x[i_x])
    fn_x.append([f_x,x[i_x]])
    
for i_y in range(ny):
    f_y=eigen_func(n_eigen,w_y,eta,L_y,y[i_y])
    fn_y.append([f_y,y[i_y]])

print('特征函数计算完成')




#########################################################
#生成随机数组，生成渗透率场实现
#################################################
seed_n=100
np.random.seed(seed_n)
n_logk=500         #渗透率场实现个数


kesi=np.zeros((n_logk,n_eigen))   #随机数数组
logk=np.zeros((n_logk,nx,ny))       #渗透率场数组


for i_logk in range(n_logk):
    kesi[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    
    # #由随机数计算渗透率场
    # for i_x in range(nx):
    #     for i_y in range(ny):
    #         logk[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi[i_logk:i_logk+1].transpose())




#修改工作目录
path = "../2_data/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()

# ##储存到二进制文件npy
# np.save('logk_train_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk,var,weight,seed_n),logk)

#2导入数据
#读取二进制文件npy
logk=np.load('logk_train_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk,var,weight,seed_n))

#渗透率场对数转化
k=np.exp(logk)

logk_image=logk.reshape(n_logk,1,nx,ny)


#################################################
seed_r=88000
np.random.seed(seed_r)
n_logk_r=1

kesi_r=np.zeros((n_logk_r,n_eigen))   #随机数数组
logk_r=np.zeros((n_logk_r,nx,ny))       #渗透率场数组


for i_logk in range(n_logk_r):
    kesi_r[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    
    #由随机数计算渗透率场
    for i_x in range(nx):
        for i_y in range(ny):
            logk_r[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_r[i_logk:i_logk+1].transpose())


# logk=logk.transpose(0,2,1)-mean_logk

logk_image_r=logk_r.reshape(n_logk_r,1,nx,ny)

k_r=np.exp(logk_r)

#####################################################################################################
#渗透率场写入程序并进行模拟
########################################################################################################

#修改工作目录
path = "../1_numerical_model/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()

print ("目录修改成功 %s" % retval)


#######################################################################
#forward calculation

# bpr_array,bsw_array,wopr_0,wwir_0,wwpr_0=run_rel(nx,ny,nz,nt,n_logk,k)
bpr_array_r,bsw_array_r,wopr_r,wwir_r,wwpr_r=run_rel(nx,ny,nz,nt,n_logk_r,k_r)

#################################################################################
#切换工作目录
path = "../2_data/"

# 查看当前工作目录
now = os.getcwd()
print ("当前工作目录为 %s" % now)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
new_path = os.getcwd()
print ("目录修改成功 %s" % new_path)
#
#
# ##################################################################################
# # #储存到二进制文件npy
# np.save('wopr_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk,weight,seed_n,pw0,pinj0,var,mean_logk,t_nday),wopr_0)
# np.save('wwpr_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk,weight,seed_n,pw0,pinj0,var,mean_logk,t_nday),wwpr_0)
# np.save('wwir_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk,weight,seed_n,pw0,pinj0,var,mean_logk,t_nday),wwir_0)

np.save('wopr_r_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_r,weight,seed_r,pw0,pinj0,var,mean_logk,t_nday),wopr_r)
np.save('wwpr_r_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_r,weight,seed_r,pw0,pinj0,var,mean_logk,t_nday),wwpr_r)
np.save('wwir_r_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_r,weight,seed_r,pw0,pinj0,var,mean_logk,t_nday),wwir_r)


#2导入数据
#读取二进制文件npy

wopr_0=np.load('wopr_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk,weight,seed_n,pw0,pinj0,var,mean_logk,t_nday))
wwpr_0=np.load('wwpr_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk,weight,seed_n,pw0,pinj0,var,mean_logk,t_nday))
wwir_0=np.load('wwir_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk,weight,seed_n,pw0,pinj0,var,mean_logk,t_nday))

wopr_r=np.load('wopr_r_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_r,weight,seed_r,pw0,pinj0,var,mean_logk,t_nday))
wwpr_r=np.load('wwpr_r_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_r,weight,seed_r,pw0,pinj0,var,mean_logk,t_nday))
wwir_r=np.load('wwir_r_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_r,weight,seed_r,pw0,pinj0,var,mean_logk,t_nday))



n_logk=50
logk_image=logk_image[0:n_logk]

qo_array=wopr_0[1:nt+1,:,0:n_logk]  # nt,nwell, n_logk
qw_array=wwpr_0[1:nt+1,:,0:n_logk]
iw_array=wwir_0[1:nt+1,:,0:n_logk]

wopr_train=qo_array.transpose(2,0,1)   # n_logk,nt,nwell
wwpr_train=qw_array.transpose(2,0,1)
wwir_train=iw_array.transpose(2,0,1)


qo_array_r=wopr_r[1:nt+1]  # nt,nwell, n_logk
qw_array_r=wwpr_r[1:nt+1]
iw_array_r=wwir_r[1:nt+1]

wopr_r_t=qo_array_r.transpose(2,0,1)   # n_logk,nt,nwell
wwpr_r_t=qw_array_r.transpose(2,0,1)
wwir_r_t=iw_array_r.transpose(2,0,1)


op_d=wopr_0[1:nt+1].min()
op_u=wopr_0[1:nt+1].max()
wp_d=wwpr_0[1:nt+1].min()
wp_u=wwpr_0[1:nt+1].max()
# wp_u=800
wi_d=wwir_0[1:nt+1].min()
wi_u=wwir_0[1:nt+1].max()

wopr_train=(wopr_train-op_d)/(op_u-op_d)
wwpr_train=(wwpr_train-wp_d)/(wp_u-wp_d)
wwir_train=(wwir_train-wi_d)/(wi_u-wi_d)

owpr_train=np.concatenate((wopr_train,wwpr_train,wwir_train),2)


wopr_r_n=(wopr_r_t-op_d)/(op_u-op_d)
wwpr_r_n=(wwpr_r_t-wp_d)/(wp_u-wp_d)
wwir_r_n=(wwir_r_t-wi_d)/(wi_u-wi_d)
owpr_r_n=np.concatenate((wopr_r_n,wwpr_r_n,wwir_r_n),2)

#################################################################


state = np.random.get_state()
np.random.shuffle(logk_image)

np.random.set_state(state)
np.random.shuffle(owpr_train)




# logk_image= torch.from_numpy(logk_image)
# logk_image= logk_image.type(torch.FloatTensor)

# owpr_train= torch.from_numpy(owpr_train)
# owpr_train= owpr_train.type(torch.FloatTensor)

n_train=len(logk_image)

############################################################################


num_code=100
hidden_size=1000
num_hidden_layer=2
num_output=n_well_pro*2+n_well_inj
fc_neuron=100

torch_seed=100
# cpu
torch.manual_seed(torch_seed)
# gpu
torch.cuda.manual_seed_all(torch_seed)    # 通过设置这个，保证每次运行按次序生成的随机数一样。·

net=conv_lstm0(nt,num_code,hidden_size,num_hidden_layer,fc_neuron,num_output,num_code,1).to(device)


#修改工作目录
path = "../3_network_parameter_results/"
# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)
# 修改当前工作目录
os.chdir( path )
# 查看修改后的工作目录
retval = os.getcwd()
print ("目录修改成功 %s" % retval)

net.load_state_dict(torch.load('0_cnn_lstm_nlogk=50_seed=100_n_well_pro=5_epoch=3000_lr=5.0e-05_batchsize=100_n_decay=10_t=109.076.ckpt'))
net.to(device)



train_time1=109.076
train_time=0
sel_time=0

num_epoch=500
BATCH_SIZE=100
n_decay=10
lr=0.0001


"""=================模型测试=================="""
net.eval()


##########################################################################
#生成渗透率场
seed_select=600
n_logk_gen=7000  #渗透率场实现个数
np.random.seed(seed_select)

kesi_gen_0=np.zeros((n_logk_gen,n_eigen))   #随机数数组
logk_gen_0=np.zeros((n_logk_gen,nx,ny))       #渗透率场数组

for i_logk in range(n_logk_gen):
    kesi_gen_0[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    #由随机数计算渗透率场

    # for i_x in range(nx):
    #     for i_y in range(ny):
    #         logk_gen_0[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_gen_0[i_logk:i_logk+1].transpose())



##################################################################################
#修改工作目录
path = "../2_data/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()
# ##储存到二进制文件npy
# np.save('logk_generate_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_gen,var,weight,seed_select),logk_gen_0)

#2导入数据
#读取二进制文件npy
logk_gen_0=np.load('logk_generate_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_gen,var,weight,seed_select))




logk_gen=logk_gen_0.copy()
kesi_gen=kesi_gen_0.copy()

sel_num_set=[50,50,50,50]


for i_sel in range(len(sel_num_set)):
    
    n_select=sel_num_set[i_sel]
        
    logk_image_gen=logk_gen.reshape(n_logk_gen,1,nx,ny)
    
    ########################################################################
    
    logk_image_gen = torch.from_numpy(logk_image_gen)
    logk_image_gen = logk_image_gen.type(torch.FloatTensor)
    logk_image_gen = logk_image_gen.to(device)
    
    mis_set=np.zeros((n_logk_gen))
    
    start_time = time.time()
    
    
    owpr_pred_com=net(logk_image_gen)
    owpr_pred_com=owpr_pred_com.cpu().detach().numpy()

 
    
    for ik in range(n_logk_gen):

        mis=np.power((owpr_r_n.flatten()-owpr_pred_com[ik].flatten()),2).sum()
        mis_set[ik]=mis  
       
    
    ind=np.argsort(mis_set)[0:n_select]
    ind.sort()
    
    
    logk_select=logk_gen[ind]
    kesi_select=kesi_gen[ind]
    
    
    sel_time_temp = time.time() - start_time                
    print('Selection time: %.4f' % (sel_time_temp))  
    
    sel_time=sel_time+sel_time_temp
    
    logk_gen=np.delete(logk_gen,ind,0)
    kesi_gen=np.delete(kesi_gen,ind,0)
    
    
    
    plt.figure(figsize=(5,3))
    plt.imshow(logk_select[-1], origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
               extent=[x.min(), x.max(), y.min(),y.max()])
    plt.xlabel('$x$',fontsize=15)
    #plt.ylabel('y')
    plt.tick_params(labelsize=12)
    # plt.yticks(np.linspace(500,2000,4))
    # plt.title('Final mean',fontsize=15)
    cbar=plt.colorbar()
    
    k_select=np.exp(logk_select)
    logk_image_select=logk_select.reshape(n_select,1,nx,ny)
    
    # sys.exit(0)
    ######################################################################################################
    ##渗透率场写入程序并进行模拟
    #########################################################################################################
    
    #修改工作目录
    path = "../1_numerical_model/"
    
    # 查看当前工作目录
    retval = os.getcwd()
    print ("当前工作目录为 %s" % retval)
    
    # 修改当前工作目录
    os.chdir( path )
    
    # 查看修改后的工作目录
    retval = os.getcwd()
    
    bpr_array_select,bsw_array_select,\
        wopr_select,wwir_select,wwpr_select=run_rel(nx,ny,nz,nt,n_select,k_select)
    
    wopr_select_t=wopr_select[1:nt+1].transpose(2,0,1)   # n_logk,nt,nwell
    wwpr_select_t=wwpr_select[1:nt+1].transpose(2,0,1)
    wwir_select_t=wwir_select[1:nt+1].transpose(2,0,1)
        
    wopr_select_n=(wopr_select_t-op_d)/(op_u-op_d)
    wwpr_select_n=(wwpr_select_t-wp_d)/(wp_u-wp_d)
    wwir_select_n=(wwir_select_t-wi_d)/(wi_u-wi_d)
    owpr_select_n=np.concatenate((wopr_select_n,wwpr_select_n,wwir_select_n),2)

    
    #########################################################################
    #提取训练数据
    logk_image=np.concatenate((logk_image,logk_image_select),0)
    owpr_train=np.concatenate((owpr_train,owpr_select_n),0)
    
    state = np.random.get_state()
    np.random.shuffle(logk_image)
    np.random.set_state(state)
    np.random.shuffle(owpr_train)
    
    
    n_train=len(logk_image)
    
    net,t_train=train_model(net.train(),logk_image,owpr_train,num_epoch,lr,BATCH_SIZE,device)
    net.eval()
    train_time=train_time+t_train
    n_logk_gen=n_logk_gen-n_select
    

training_time=train_time1+train_time
################################################################################

#修改工作目录
path = "../3_network_parameter_results/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
new_path = os.getcwd()
print ("目录修改成功 %s" % new_path)

torch.save(net.state_dict(),\
    'cnn_lstm_offline_nlogk=%d_seed_select=%d_n_well_pro=%d_epoch=%d_batchsize=%d_n_decay=%d_t=%.3f_t_sel=%.3f.ckpt'%(n_train,\
    seed_select,n_well_pro,num_epoch,BATCH_SIZE,n_decay,training_time,sel_time))

# sys.exit(0)



"""=================模型测试=================="""
net.eval()


##########################################################################
#生成渗透率场
seed=200
n_logk_test=200 #渗透率场实现个数
np.random.seed(seed)

kesi_test=np.zeros((n_logk_test,n_eigen))   #随机数数组
logk_test=np.zeros((n_logk_test,nx,ny))       #渗透率场数组

for i_logk in range(n_logk_test):
    kesi_test[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    #由随机数计算渗透率场

    for i_x in range(nx):
        for i_y in range(ny):
            logk_test[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_test[i_logk:i_logk+1].transpose())


#渗透率场对数转化
k_test=np.exp(logk_test)
logk_test_image=logk_test.reshape(n_logk_test,1,nx,ny)



######################################################################################################
##渗透率场写入程序并进行模拟
#########################################################################################################
#修改工作目录
path = "../1_numerical_model/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()

print ("目录修改成功 %s" % retval)


# bpr_array_test,bsw_array_test,wopr_0_test,wwir_0_test,wwpr_0_test=run_rel(nx,ny,nz,nt,n_logk_test,k_test)

########################################################################
#################################################################################
#切换工作目录
path = "../2_data/"

# 查看当前工作目录
now = os.getcwd()
print ("当前工作目录为 %s" % now)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
new_path = os.getcwd()
print ("目录修改成功 %s" % new_path)
#
#
# ###################################################################################
# ###储存到二进制文件npy
# np.save('wopr_test_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_test,weight,seed,pw0,pinj0,var,mean_logk,t_nday),wopr_0_test)
# np.save('wwpr_test_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_test,weight,seed,pw0,pinj0,var,mean_logk,t_nday),wwpr_0_test)
# np.save('wwir_test_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_test,weight,seed,pw0,pinj0,var,mean_logk,t_nday),wwir_0_test)


#2导入数据
#读取二进制文件npy

wopr_0_test=np.load('wopr_test_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_test,weight,seed,pw0,pinj0,var,mean_logk,t_nday))
wwpr_0_test=np.load('wwpr_test_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_test,weight,seed,pw0,pinj0,var,mean_logk,t_nday))
wwir_0_test=np.load('wwir_test_data_nt=%d_N=%d_weight=%f_seed=%d_pw=%d_pinj=%d_var=%.2f_mean=%d_tnady=%.2f.npy'%(nt,n_logk_test,weight,seed,pw0,pinj0,var,mean_logk,t_nday))



qo_array_test=wopr_0_test[1:nt+1]
qw_array_test=wwpr_0_test[1:nt+1]
iw_array_test=wwir_0_test[1:nt+1]


wopr_test1=qo_array_test.transpose(2,0,1)
wwpr_test1=qw_array_test.transpose(2,0,1)
wwir_test1=iw_array_test.transpose(2,0,1)

wopr_test=(wopr_test1-op_d)/(op_u-op_d)
wwpr_test=(wwpr_test1-wp_d)/(wp_u-wp_d)
wwir_test=(wwir_test1-wi_d)/(wi_u-wi_d)

owpr_test=np.concatenate((wopr_test,wwpr_test,wwir_test),2)
########################################################################


logk_test_image = torch.from_numpy(logk_test_image)
logk_test_image = logk_test_image.type(torch.FloatTensor)
logk_test_image = logk_test_image.to(device)



l2_set=np.empty((n_logk_test))
r2_set=np.empty((n_logk_test))

op_test_pred=np.zeros((n_logk_test,nt,n_well_pro))
wp_test_pred=np.zeros((n_logk_test,nt,n_well_pro))
wi_test_pred=np.zeros((n_logk_test,nt,n_well_inj))

start_time = time.time()

owpr_pred=net(logk_test_image)
owpr_pred=owpr_pred.cpu().detach().numpy()

op_test_pred=owpr_pred[:,:,0:n_well_pro]*(op_u-op_d)+op_d
wp_test_pred=owpr_pred[:,:,n_well_pro:2*n_well_pro]*(wp_u-wp_d)+wp_d
wi_test_pred=owpr_pred[:,:,2*n_well_pro:]*(wi_u-wi_d)+wi_d

elapsed = time.time() - start_time                
print('Prediction time: %.4f' % (elapsed))  

for ik in range(n_logk_test):
    error_l2 = np.linalg.norm(owpr_test[ik].flatten()-owpr_pred[ik].flatten(),2)/np.linalg.norm(owpr_test[ik].flatten(),2)
    print('Error L2: %e' % (error_l2))
    l2_set[ik]=error_l2
    
    R2=1-np.sum((owpr_test[ik].flatten()-owpr_pred[ik].flatten())**2)/np.sum((owpr_test[ik].flatten()-owpr_test[ik].flatten().mean())**2)
    print('oefficient of determination  R2: %e' % (R2))
    r2_set[ik]=R2
        
   


pro_L2_mean=np.mean(l2_set)
pro_L2_var=np.var(l2_set)
pro_R2_mean=np.mean(r2_set)
pro_R2_var=np.var(r2_set)

print('pro L2 mean:')
print(pro_L2_mean)
print('pro L2 var:')
print(pro_L2_var)

print('pro R2 mean:')
print(pro_R2_mean)
print('pro R2 var:')
print(pro_R2_var)



#选择观测时空点
#第一个点：时间t=5,位置x=200,y=200
obs_t1=nt-1


#第一个点：时间t=8 ,位置x=200,y=800
obs_t2=nt-10


real_h1=wopr_test1[:,obs_t1].flatten()
pred_h1=op_test_pred[:,obs_t1].flatten()

real_h2=wwpr_test1[:,obs_t1].flatten()
pred_h2=wp_test_pred[:,obs_t1].flatten()

real_h3=wwir_test1[:,obs_t1].flatten()
pred_h3=wi_test_pred[:,obs_t1].flatten()



# col_x_ticks = np.arange(199.7,202.3, 0.4)
plt.figure(figsize=(5,5))
# plt.plot([-100,500],[-100,500],'k-',linewidth=2)
plt.scatter(real_h1,pred_h1,marker='o',c='',edgecolors='b',label='Point 1')
plt.scatter(real_h2,pred_h2,marker='s',c='',edgecolors='r',label='Point 2')
plt.xlabel('Reference (m$^3$/day)',fontsize=18)
plt.ylabel('Prediction (m$^3$/day)',fontsize=18)
plt.title("Production rate")
# plt.xlim(wqp_d,wqp_u-100)
# plt.ylim(wqp_d,wqp_u-100)
# plt.xticks(col_x_ticks)
# plt.yticks(col_x_ticks)
plt.legend(fontsize=12)



    ######################################################################
    ############################# Plotting_3 #############################
    ######################################################################   
#统计结果展示    

num_bins = 15

l2_x_ticks = np.arange(0,0.0016, 0.0003)

plt.figure(figsize=(6,4))
plt.hist(l2_set, num_bins)
plt.title(r'$Histogram\ \ of\ \  relative\ \ L_2\ \ error$')
#plt.title(r'$Histogram\ \ of\ \  relative\ \ L_2\ \ error\ \ \left(TgNN\right)$')
#plt.xlim(0,0.0015)
# plt.xticks(l2_x_ticks)

num_bins2 = 15
plt.figure(figsize=(6,4))
plt.hist(r2_set, num_bins2)
plt.title(r'$Histogram\ \ of\ \  R^2\ \ score$')
#plt.title(r'$Histogram\ \ of\ \  R^2\ \ score\ \ \left(TgNN\right)$')
# plt.xlim(0.9,1)
# plt.savefig(fig_path+'4_2.png')




n_plot_set=[24]
for sam1 in n_plot_set:

    ######################################################
    ####### Row 3: oil rate ##################

    plt.figure(figsize=(18,15))
    for iwell in range(n_well_pro):
        plt.subplot(3,3,iwell+1)
        plt.plot(range(nt),wopr_test1[sam1,:,iwell],'k-',label='Reference')
        plt.plot(range(nt),op_test_pred[sam1,:,iwell],'r--',label='Prediction')
        plt.xlabel('Time-step',fontsize=15)
        plt.ylabel('Oil production rate (m$^3$/day)',fontsize=15)
        plt.title('PRO %d'%(iwell+1),fontsize=15)
        plt.ylim(-10,850)
        plt.tick_params(labelsize=13)
        plt.legend(fontsize=13)

    plt.subplots_adjust(left = 0.1,right = 0.9 ,wspace = 0.3,hspace=0.3)
    

    ####### Row 2: water rate ##################

    plt.figure(figsize=(18,15))
    for iwell in range(n_well_pro):
        plt.subplot(3,3,iwell+1)
        plt.plot(range(nt),wwpr_test1[sam1,:,iwell],'k-',label='Reference')
        plt.plot(range(nt),wp_test_pred[sam1,:,iwell],'r--',label='Prediction')
        plt.xlabel('Time-step',fontsize=15)
        plt.ylabel('Water production rate (m$^3$/day)',fontsize=15)
        plt.title('PRO %d'%(iwell+1),fontsize=15)
        plt.ylim(-10,850)
        plt.tick_params(labelsize=13)
        plt.legend(fontsize=13)

    
    plt.subplots_adjust(left = 0.1,right = 0.9 ,wspace = 0.3,hspace=0.3)
    

    ####### Row 2: water injection rate ##################

    plt.figure(figsize=(18,15))
    for iwell in range(n_well_inj):
        plt.subplot(3,3,iwell+1)
        plt.plot(range(nt),wwir_test1[sam1,:,iwell],'k-',label='Reference')
        plt.plot(range(nt),wi_test_pred[sam1,:,iwell],'r--',label='Prediction')
        plt.xlabel('Time-step',fontsize=15)
        plt.ylabel('Water injection rate (m$^3$/day)',fontsize=15)
        plt.title('INJ %d'%(iwell+1),fontsize=15)
        plt.ylim(-10,850)
        plt.tick_params(labelsize=13)
        plt.legend(fontsize=13)

    plt.subplots_adjust(left = 0.1,right = 0.9 ,wspace = 0.3,hspace=0.3)
    


