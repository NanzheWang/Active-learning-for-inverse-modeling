# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 18:13:57 2022

@author: WNZ
"""






import torch
import torch.nn as nn
import torch.nn.functional as func
import random
import scipy.io as scio

from pyDOE import lhs
import math
import numpy as np
import matplotlib.pyplot as plt
import time
import re
import os
import os.path
import operator
import sys
from KLE import eigen_value_solution,sort_lamda,eigen_func
from forward_model_func_with_h_input_k1 import forward_model
from cnn_lstm import conv_lstm0,conv_lstm_ctrl,conv_lstm_ctrl_ae,lstm


torch_seed=100
# cpu
torch.manual_seed(torch_seed)
# gpu
torch.cuda.manual_seed_all(torch_seed)    # 通过设置这个，保证每次运行按次序生成的随机数一样。·



plt.rcParams['figure.max_open_warning']=100
plt.rcParams['savefig.dpi'] = 100 #图片像素
plt.rcParams['figure.dpi'] = 100 #分辨率



#############################################################################################
#############################################################################################
#########################################################################
#设备设置
device = torch.device('cuda:0')
  


##################################
###参数设置
######################################

n_logk=500
#渗透率场设置
mean_logk=0
var=1.0
L_x= 1220    #区域长度
L_y= 1220
domain=L_x*L_y
eta_x=L_x*0.4      #相关长度
eta_y=L_y*0.4      #相关长度

nx=61     #网格个数
ny=61
nz=1
nt=50      #时间步数

dx=20
dy=20
dz=20
dt=0.2

x=np.arange(1,nx+1,1)
x=x*dx
y=np.arange(1,ny+1,1)
y=y*dy


weight=0.85


##############
#地层参数
ss=0.0001



###########################################
###计算所需特征值个数
#########################################
n_test=50
lamda_x,w_x0,cumulate_lamda_x=eigen_value_solution(eta_x,L_x,var,n_test)
lamda_y,w_y0,cumulate_lamda_y=eigen_value_solution(eta_y,L_y,var,n_test)


############################################################
#二维特征值计算，混合，排序，截断
lamda_xy,w_x,w_y,n_eigen,cum_lamda=sort_lamda(lamda_x,w_x0,lamda_y,w_y0,domain,var,weight)

#########################################################
#根据weight获取所需计算特征值个数,并计算特征值以及特征函数值
#################################################
fn_x=[]
fn_y=[]


for i_x in range(nx):
    f_x=eigen_func(n_eigen,w_x,eta_x,L_x,x[i_x])
    fn_x.append([f_x,x[i_x]])
    
for i_y in range(ny):
    f_y=eigen_func(n_eigen,w_y,eta_y,L_y,y[i_y])
    fn_y.append([f_y,y[i_y]])

print('特征函数计算完成')

#########################################################
xp1=6
yp1=6

xp2=6
yp2=22

xp3=6
yp3=38

xp4=6
yp4=54

xp5=22
yp5=6

xp6=22
yp6=22

xp7=22
yp7=38

xp8=22
yp8=54

xp9=38
yp9=6

xp10=38
yp10=22

xp11=38
yp11=38

xp12=38
yp12=54

xp13=54
yp13=6

xp14=54
yp14=22

xp15=54
yp15=38

xp16=54
yp16=54

xp_set=[xp1,xp2,xp3,xp4,xp5,xp6,xp7,xp8,xp9,xp10,xp11,xp12,xp13,xp14,xp15,xp16]
yp_set=[yp1,yp2,yp3,yp4,yp5,yp6,yp7,yp8,yp9,yp10,yp11,yp12,yp13,yp14,yp15,yp16]
n_point=len(xp_set)
#########################################################
#生成随机数组，生成渗透率场实现
#################################################
seed_n=100
np.random.seed(seed_n)


kesi=np.zeros((n_logk,n_eigen))   #随机数数组
logk=np.zeros((n_logk,nx,ny))       #渗透率场数组


for i_logk in range(n_logk):
    kesi[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    
#     #由随机数计算渗透率场
#     for i_x in range(nx):
#         for i_y in range(ny):
#             logk[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi[i_logk:i_logk+1].transpose())




#修改工作目录
path = "../1_data/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()

# ##储存到二进制文件npy
# np.save('logk_train_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk,var,weight,seed_n),logk)

#2导入数据
#读取二进制文件npy
logk=np.load('logk_train_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk,var,weight,seed_n))


logk_image=logk.reshape(n_logk,1,nx,ny)

k=np.exp(logk)



#################################################
seed_r=500
np.random.seed(seed_r)
n_logk_r=1

kesi_r=np.zeros((n_logk_r,n_eigen))   #随机数数组
logk_r=np.zeros((n_logk_r,nx,ny))       #渗透率场数组


for i_logk in range(n_logk_r):
    kesi_r[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    
    #由随机数计算渗透率场
    for i_x in range(nx):
        for i_y in range(ny):
            logk_r[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_r[i_logk:i_logk+1].transpose())


# logk=logk.transpose(0,2,1)-mean_logk

logk_image_r=logk_r.reshape(n_logk_r,1,nx,ny)

k_r=np.exp(logk_r)

# ##############################################################################################
# plt.figure(figsize=(8.5,3))
# plt.subplot(121)
# plt.imshow(logk_r[0], origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
#            extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
# plt.xlabel('$x$',fontsize=15)
# plt.ylabel('$y$',fontsize=15)
# plt.title("ln$K(x,y)$",fontsize=15)
# cbar=plt.colorbar()

# ##############################################################################################
# plt.figure(figsize=(8.5,3))
# plt.subplot(121)
# plt.imshow(k_r[0], origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
#            extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
# plt.xlabel('$x$',fontsize=15)
# plt.ylabel('$y$',fontsize=15)
# plt.title("ln$K(x,y)$",fontsize=15)
# cbar=plt.colorbar()


#####################################################################################################
#渗透率场写入程序并进行模拟
########################################################################################################

#修改工作目录
path = "../1_numerical_model/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()


# hh_all=forward_model(k,nt,nx,ny)

# hh_ref=forward_model(k_r,nt,nx,ny)

# ##################################################################################
# ##储存到二进制文件npy
# np.save('hh_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk,var,weight,seed_n),hh_all)
# np.save('hh_ref_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_r,var,weight,seed_r),hh_ref)

#2导入数据
#读取二进制文件npy
hh_all=np.load('hh_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk,var,weight,seed_n))
hh_ref=np.load('hh_ref_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_r,var,weight,seed_r))

h_seq_0=np.zeros((n_logk,nt,n_point))
for i in range(n_point):
    h_seq_0[:,:,i]=hh_all[:,:,xp_set[i],yp_set[i]]

h_seq_r=np.zeros((n_logk_r,nt,n_point))
for i in range(n_point):
    h_seq_r[:,:,i]=hh_ref[:,:,xp_set[i],yp_set[i]]



# sys.exit(0)
n_logk_train=1
hh=hh_all[0:n_logk_train]
h_seq=h_seq_0[0:n_logk_train]

logk_image_train=logk_image[0:n_logk_train]
kesi_train=kesi[0:n_logk_train]

#################################################################################

h_seq_d=h_seq_0.min()
h_seq_u=h_seq_0.max()


h_seq_train=(h_seq-h_seq_d)/(h_seq_u-h_seq_d)

h_seq_r_n=(h_seq_r-h_seq_d)/(h_seq_u-h_seq_d)


#########################################################################
#提取训练数据

logk_image_train= torch.from_numpy(logk_image_train)
logk_image_train= logk_image_train.type(torch.FloatTensor)

h_seq_train= torch.from_numpy(h_seq_train)
h_seq_train= h_seq_train.type(torch.FloatTensor)


n_train=len(logk_image_train)




############################################################################

num_code=100
hidden_size=1000
num_hidden_layer=2
num_output=n_point
fc_neuron=100

torch_seed=100
# cpu
torch.manual_seed(torch_seed)
# gpu
torch.cuda.manual_seed_all(torch_seed)    # 通过设置这个，保证每次运行按次序生成的随机数一样。·




net=conv_lstm0(nt,num_code,hidden_size,num_hidden_layer,fc_neuron,num_output,num_code,1).to(device)
#net=conv_lstm_ctrl_ae(nt,num_code+n_pro+n_inj,hidden_size,num_hidden_layer,fc_neuron,num_output,num_code,1).to(device)


################################################################################

# #修改工作目录
# path = "../3_network_parameter_results/"
# # 查看当前工作目录
# retval = os.getcwd()
# print ("当前工作目录为 %s" % retval)
# # 修改当前工作目录
# os.chdir( path )
# # 查看修改后的工作目录
# retval = os.getcwd()
# print ("目录修改成功 %s" % retval)

# net.load_state_dict(torch.load('3_cnn_lstm_nlogk=100_seed=100_npoint=16_epoch=3000_batchsize=100_n_decay=10_t=182.706.ckpt'))
# net.to(device)
# # net.eval()


"""=================模型测试=================="""
# net.eval()




##########################################################################
#生成渗透率场
seed_select=800
n_logk_select=5000  #渗透率场实现个数
np.random.seed(seed_select)

kesi_select=np.zeros((n_logk_select,n_eigen))   #随机数数组

for i_logk in range(n_logk_select):
    kesi_select[i_logk,:]=np.random.randn(n_eigen)   #随机数数组

kesi_select_0=kesi_select.copy()

def greedy_sample(n,existing,new):
    n_exist=existing.shape[0]
    n_new=new.shape[0]
    
    l2_array=np.zeros((n_new,n_exist))
    for ik in range(n_new):
        for i in range(n_exist):
            error_l2 = np.linalg.norm(existing[i]-new[ik],2)/np.linalg.norm(existing[i],2)
            print('%d  Error L2: %e' % (ik*n_exist+i+1,error_l2))
            l2_array[ik,i]=error_l2
    
    l2_min=l2_array.min(1)
    ind=np.argsort(l2_min)[-n:]
    
    new_select=new[ind]
    left=np.delete(new,ind,0)
    l2_array_left=np.delete(l2_array,ind,0)
    return new_select,left,l2_array_left

def greedy_sample_2(existing,new,l2_array_left):
    n_exist=existing.shape[0]
    n_new=new.shape[0]
    
    l2_array=np.zeros((n_new,1))
    for ik in range(n_new):

        error_l2 = np.linalg.norm(existing[-1]-new[ik],2)/np.linalg.norm(existing[-1],2)
        print('%d  Error L2: %e' % (ik,error_l2))
        l2_array[ik,0]=error_l2
    
    l2_array=np.concatenate((l2_array_left,l2_array),1)
    l2_min=l2_array.min(1)
    ind=np.argsort(l2_min)[-1:]
    
    new_select=new[ind]
    left=np.delete(new,ind,0)
    l2_array_left=np.delete(l2_array,ind,0)
    return new_select,left,l2_array_left


n_select=209

sel_start_time=time.time()

kesi_select,kesi_left,l2_array_left=greedy_sample(1,kesi_train,kesi_select)

for i_sel in range(n_select-1):
    kesi_select_new,kesi_left,l2_array_left=greedy_sample_2(np.concatenate((kesi_train,kesi_select),0),kesi_left,l2_array_left)
    kesi_select=np.concatenate((kesi_select,kesi_select_new),0)

sel_end_time=time.time()
sel_time=sel_end_time-sel_start_time
print("选择所需时间：%.3f"%(sel_time))


plt.figure()
plt.scatter(kesi_select[:,0],kesi_select[:,1])
plt.scatter(kesi_select_0[0:n_select,0],kesi_select_0[0:n_select,1])


# sys.exit(0)


logk_select=np.zeros((n_select,nx,ny))       #渗透率场数组

for i_logk in range(n_select):

    for i_x in range(nx):
        for i_y in range(ny):
            logk_select[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_select[i_logk:i_logk+1].transpose())



k_select=np.exp(logk_select)
logk_image_select=logk_select.reshape(n_select,1,nx,ny)


# sys.exit(0)
######################################################################################################
##渗透率场写入程序并进行模拟
#########################################################################################################

#修改工作目录
path = "../1_numerical_model/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()


hh_select=forward_model(k_select,nt,nx,ny)


# ##################################################################################
# ##储存到二进制文件npy
# np.save('hh_test_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_test,var,weight,seed_test),hh_test)

# #2导入数据
# #读取二进制文件npy
# hh_test=np.load('hh_test_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_test,var,weight,seed_test))

h_seq_select=np.zeros((n_select,nt,n_point))

for i in range(n_point):
    h_seq_select[:,:,i]=hh_select[:,:,xp_set[i],yp_set[i]]





h_seq_select=(h_seq_select-h_seq_d)/(h_seq_u-h_seq_d)


#########################################################################
#提取训练数据
logk_image_train=np.concatenate((logk_image_train.cpu().detach().numpy(),logk_image_select),0)
logk_image_train= torch.from_numpy(logk_image_train)
logk_image_train= logk_image_train.type(torch.FloatTensor)


h_seq_train=np.concatenate((h_seq_train.cpu().detach().numpy(),h_seq_select),0)
h_seq_train= torch.from_numpy(h_seq_train)
h_seq_train= h_seq_train.type(torch.FloatTensor)


n_train=len(logk_image_train)



"""=================训练神经网络-second stage=================="""
net.train()
#训练数据分批处理
BATCH_SIZE = 100      # 批训练的数据个数
N_batch=math.ceil(n_train/BATCH_SIZE )

k_train_set=[]
out_train_set=[]


for i_batch in range(int(N_batch)):
    k_train_set.append(logk_image_train[BATCH_SIZE*i_batch:BATCH_SIZE*(i_batch+1)])
    out_train_set.append(h_seq_train[BATCH_SIZE*i_batch:BATCH_SIZE*(i_batch+1)])
    
# 定义神经网络优化器
LR=0.00005
# LR=0.001

optimizer=torch.optim.Adam([
    {'params': net.parameters()},   
    # {'params': Net_s.parameters()},   
# ],lr=LR,weight_decay=0.005)
],lr=LR) 



lr_list=[]

#定义loss数组
loss_set=[]
f1_set=[]
f2_set=[]

num_epoch=3000
n_decay=10

start_time = time.time()  
##########################################################################
##分批训练
for epoch in range(num_epoch):   # 训练所有!整套!数据 3 次
    for ite in range(N_batch):
        batch_k=k_train_set[ite].to(device)
        batch_y=out_train_set[ite].to(device)
        
    
        optimizer.zero_grad()
#        p_pred,k_pred=net(batch_k,batch_ctrl)
        h_pred=net(batch_k)
        # p_pred=net(batch_k)
        # p_pred=net(batch_ctrl)
        
        f1=torch.pow((h_pred-batch_y),2).mean()
#        f2=torch.pow((k_pred-batch_k),2).mean()
        
#        loss=f1+f2
        loss=f1
        loss.backward()
        optimizer.step()        
        loss=loss.data
        f1=f1.data
#        f2=f2.data
        loss_set.append(loss)
        f1_set.append(f1)
#        f2_set.append(f2)
        print('Epoch: ', epoch, '| Step: ', ite, '|loss: ',loss)
        lr_list.append(optimizer.state_dict()['param_groups'][0]['lr'])

    if (epoch+1) % n_decay == 0 and optimizer.state_dict()['param_groups'][0]['lr']>0.00005:
        for p in optimizer.param_groups:
            p['lr'] *= 0.9


end_time = time.time() 

training_time = end_time  - start_time                
print('Training time: %.4f' % (training_time))
# training_time1=184.769
# training_time = training_time1+training_time2   

plt.figure()     
plt.plot(range(len(loss_set)),loss_set)
plt.xlabel('Iteration')
plt.ylabel('loss')

plt.figure()     
plt.plot(range(len(f1_set)),f1_set)
plt.xlabel('Iteration')
plt.ylabel('f1')


plt.figure()     
plt.plot(range(len(f2_set)),f2_set)
plt.xlabel('Iteration')
plt.ylabel('f2')


plt.figure()  
plt.plot(range(len(lr_list)),lr_list,color = 'r')  
plt.xlabel('Iteration')
plt.ylabel('Learning rate')    


# sys.exit(0)
################################################################################

#修改工作目录
path = "../3_network_parameter_results/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
new_path = os.getcwd()
print ("目录修改成功 %s" % new_path)

torch.save(net.state_dict(),\
    'cnn_lstm_greedy_kesi_from0_nlogk=%d_seed=%d_npoint=%d_epoch=%d_batchsize=%d_n_decay=%d_t=%.3f_t_sample=%.3f.ckpt'%(n_train,\
    seed_select,n_point,num_epoch,BATCH_SIZE,n_decay,training_time,sel_time))

# sys.exit(0)

##########################################################################
net.eval()

#生成渗透率场
seed_test=200
n_logk_test=100  #渗透率场实现个数
np.random.seed(seed_test)

kesi_test=np.zeros((n_logk_test,n_eigen))   #随机数数组
logk_test=np.zeros((n_logk_test,nx,ny))       #渗透率场数组

for i_logk in range(n_logk_test):
    kesi_test[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    #由随机数计算渗透率场

    for i_x in range(nx):
        for i_y in range(ny):
            logk_test[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_test[i_logk:i_logk+1].transpose())


#渗透率场对数转化
# logk_test=logk_test.transpose(0,2,1)-mean_logk
k_test=np.exp(logk_test)
logk_image_test=logk_test.reshape(n_logk_test,1,nx,ny)


######################################################################################################
##渗透率场写入程序并进行模拟
#########################################################################################################

#修改工作目录
path = "../1_numerical_model/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()


# hh_test=forward_model(k_test,nt,nx,ny)


# ##################################################################################
# ##储存到二进制文件npy
# np.save('hh_test_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_test,var,weight,seed_test),hh_test)

#2导入数据
#读取二进制文件npy
hh_test=np.load('hh_test_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk_test,var,weight,seed_test))

h_seq_test=np.zeros((n_logk_test,nt,n_point))

for i in range(n_point):
    h_seq_test[:,:,i]=hh_test[:,:,xp_set[i],yp_set[i]]


########################################################################

logk_image_test = torch.from_numpy(logk_image_test)
logk_image_test = logk_image_test.type(torch.FloatTensor)
logk_image_test = logk_image_test.to(device)



l2_set=np.zeros((n_logk_test))
r2_set=np.zeros((n_logk_test))




start_time = time.time()
h_test_pred=net(logk_image_test)
h_test_pred=h_test_pred.cpu().detach().numpy()

h_test_pred=h_test_pred*(h_seq_u-h_seq_d)+h_seq_d

elapsed = time.time() - start_time                
print('Prediction time: %.4f' % (elapsed))  

for ik in range(n_logk_test):
    error_l2 = np.linalg.norm(h_seq_test[ik].flatten()-h_test_pred[ik].flatten(),2)/np.linalg.norm(h_seq_test[ik].flatten(),2)
    print('Error L2: %e' % (error_l2))
    l2_set[ik]=error_l2
    
    R2=1-np.sum((h_seq_test[ik].flatten()-h_test_pred[ik].flatten())**2)/np.sum((h_seq_test[ik].flatten()-h_seq_test[ik].flatten().mean())**2)
    print('oefficient of determination  R2: %e' % (R2))
    r2_set[ik]=R2
        
   



L2_mean=np.mean(l2_set)
L2_var=np.var(l2_set)
R2_mean=np.mean(r2_set)
R2_var=np.var(r2_set)

print('L2 mean:')
print(L2_mean)
print('L2 var:')
print(L2_var)

print('R2 mean:')
print(R2_mean)
print('R2 var:')
print(R2_var)



# sys.exit(0)
#######################################################
#结果展示    
nr_test_plot=5
it=10

    ######################################################################
    ############################# Plotting_2 #############################
    ######################################################################   
#结果展示    

#选择观测时空点
#第一个点：时间t=5,位置x=200,y=200
obs_t1=nt-1


#第一个点：时间t=8 ,位置x=200,y=800
obs_t2=nt-10


real_h1=h_seq_test[:,obs_t1].flatten()
pred_h1=h_test_pred[:,obs_t1].flatten()

real_h2=h_seq_test[:,obs_t2].flatten()
pred_h2=h_test_pred[:,obs_t2].flatten()



# col_x_ticks = np.arange(199.7,202.3, 0.4)
plt.figure(figsize=(5,5))
# plt.plot([-100,500],[-100,500],'k-',linewidth=2)
plt.scatter(real_h1,pred_h1,marker='o',c='',edgecolors='b',label='Point 1')
plt.scatter(real_h2,pred_h2,marker='s',c='',edgecolors='r',label='Point 2')
plt.xlabel('Reference (m$^3$/day)',fontsize=18)
plt.ylabel('Prediction (m$^3$/day)',fontsize=18)
plt.title("Production rate")
# plt.xlim(wqp_d,wqp_u-100)
# plt.ylim(wqp_d,wqp_u-100)
# plt.xticks(col_x_ticks)
# plt.yticks(col_x_ticks)
plt.legend(fontsize=12)



    ######################################################################
    ############################# Plotting_3 #############################
    ######################################################################   
#统计结果展示    

num_bins = 15

l2_x_ticks = np.arange(0,0.0016, 0.0003)

plt.figure(figsize=(6,4))
plt.hist(l2_set, num_bins)
plt.title(r'$Histogram\ \ of\ \  relative\ \ L_2\ \ error$')
#plt.title(r'$Histogram\ \ of\ \  relative\ \ L_2\ \ error\ \ \left(TgNN\right)$')
#plt.xlim(0,0.0015)
# plt.xticks(l2_x_ticks)

num_bins2 = 15
plt.figure(figsize=(6,4))
plt.hist(r2_set, num_bins2)
plt.title(r'$Histogram\ \ of\ \  R^2\ \ score$')
#plt.title(r'$Histogram\ \ of\ \  R^2\ \ score\ \ \left(TgNN\right)$')
# plt.xlim(0.9,1)
# plt.savefig(fig_path+'4_2.png')



n_plot_set=[0]
for sam1 in n_plot_set:
    ######################################################
    ####### Row 3: oil rate ##################

    plt.figure(figsize=(21,15))
    for iwell in range(n_point):
        plt.subplot(4,4,iwell+1)
        plt.plot(range(nt),h_seq_test[sam1,:,iwell],'k-',label='Reference')
        plt.plot(range(nt),h_test_pred[sam1,:,iwell],'r--',label='Prediction')
        plt.xlabel('Control step',fontsize=15)
        plt.ylabel('BHP (bar)',fontsize=15)
        plt.title('PRO %d'%(iwell+1),fontsize=15)
        # plt.ylim(227,258)
        plt.tick_params(labelsize=13)
        # plt.legend(fontsize=13)
    plt.subplots_adjust(left = 0.1,right = 0.9 ,wspace = 0.3,hspace=0.3)






















