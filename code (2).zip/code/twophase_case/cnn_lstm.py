# -*- coding: utf-8 -*-
"""
Created on Wed Jan  5 02:51:23 2022

@author: WNZ
"""


import torch
from torch.nn import Linear,Tanh,Sequential,ReLU,Softplus,ELU,LeakyReLU
import torch.nn.functional as F
from torch.autograd import Variable
import torch.utils.data as Data
import torch.nn as nn
import torch.nn.functional as func
from torch import nn
from collections import OrderedDict

#######################################################################


#######################################################################
"""=================构建神经网络=================="""

class Swish(nn.Module):
	def __init__(self, inplace=True):
		super(Swish, self).__init__()
		self.inplace = inplace

	def forward(self, x):
		if self.inplace:
			x.mul_(torch.sigmoid(x))
			return x
		else:
			return x * torch.sigmoid(x)
#设置保留小数位数
torch.set_printoptions(precision=7, threshold=None, edgeitems=None, linewidth=None, profile=None)




#################################################################
# Convolutional neural network 
class conv_swish(nn.Module):
    def __init__(self, num_code=100,in_channel=1,bn=False):
        super(conv_swish, self).__init__()
        self.num_code=num_code
        if bn:
            self.encode = nn.Sequential(
                nn.Conv2d(in_channel, 16, kernel_size=3, stride=1, padding=0),
                nn.BatchNorm2d(16),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
                # nn.MaxPool2d(kernel_size=2, stride=2)
    
    
    
                nn.Conv2d(16, 32, kernel_size=5, stride=2, padding=1),
                nn.BatchNorm2d(32),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
                # nn.MaxPool2d(kernel_size=2, stride=2),
    
    
    
                nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
                nn.BatchNorm2d(64),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
    
    
    
                nn.Conv2d(64, 128, kernel_size=5, stride=2, padding=1),
                nn.BatchNorm2d(128),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
                
                nn.Conv2d(128,256, kernel_size=3, stride=1, padding=0),
                nn.BatchNorm2d(256),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
                 
                )
        else:
            self.encode = nn.Sequential(
                nn.Conv2d(in_channel, 16, kernel_size=3, stride=1, padding=0),
                # nn.BatchNorm2d(16),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
                # nn.MaxPool2d(kernel_size=2, stride=2)
    
    
    
                nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1),
                # nn.BatchNorm2d(32),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
                # nn.MaxPool2d(kernel_size=2, stride=2),
    
    
    
                nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
                # nn.BatchNorm2d(64),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
    
    
    
                nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
                # nn.BatchNorm2d(128),
                # nn.ReLU(),
                Swish(),
                # nn.Tanh(),
                # nn.Sigmoid(),
                # nn.Softplus(beta=1, threshold=20),
                
                # nn.Conv2d(128,256, kernel_size=3, stride=1, padding=0),
                # # nn.BatchNorm2d(128),
                # # nn.ReLU(),
                # Swish(),
                # # nn.Tanh(),
                # # nn.Sigmoid(),
                # # nn.Softplus(beta=1, threshold=20),

                # nn.Conv2d(256,512, kernel_size=3, stride=1, padding=0),
                # # nn.BatchNorm2d(128),
                # # nn.ReLU(),
                # Swish(),
                # # nn.Tanh(),
                # # nn.Sigmoid(),
                # # nn.Softplus(beta=1, threshold=20),
                                
                # nn.Conv2d(512,1024, kernel_size=3, stride=1, padding=0),
                # # nn.BatchNorm2d(128),
                # # nn.ReLU(),
                # Swish(),
                # # nn.Tanh(),
                # # nn.Sigmoid(),
                # # nn.Softplus(beta=1, threshold=20),

                # nn.Conv2d(1024,1024, kernel_size=1, stride=1, padding=0),
                # # nn.BatchNorm2d(128),
                # # nn.ReLU(),
                # Swish(),
                # # nn.Tanh(),
                # # nn.Sigmoid(),
                # # nn.Softplus(beta=1, threshold=20),
                                
                )    
        if num_code>0:
            self.fc = nn.Sequential(                
            nn.Linear(128*7 *7, num_code),
            # nn.Linear(1024, 800),
            Swish(),
            # nn.Linear(1024, num_code),
            # nn.ReLU(),
            # nn.Linear(num_code, 256*5 *5),
            )

    def forward(self, x):
        code = self.encode(x)
        if self.num_code>0:
            code = code.view(code.size(0), -1)
            code = self.fc(code)
           
        return code 

########################################################


class lstm(nn.Module):
    def __init__(self, input_size=113, hidden_size=130, num_layers=2, fc_neuron=100,output_size=13):
        super(lstm, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        # self.fc = nn.Linear(hidden_size, output_size)
        self.fc = nn.Sequential(  
            nn.Linear(hidden_size, fc_neuron),
            # nn.ReLU(),
            nn.LeakyReLU(0.2),
            # nn.Softplus(beta=1, threshold=20),
            nn.Linear(fc_neuron, output_size),
            )
        # 创建LSTM层和linear层，LSTM层提取特征，linear层用作最后的预测
        # LSTM算法接受三个输入：先前的隐藏状态，先前的单元状态和当前输入。
    
    def forward(self, x):
        # Set initial hidden and cell states 
        # h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(device) 
        # c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(device)
        
        # Forward propagate LSTM
        # out, _ = self.lstm(x, (h0, c0))  # out: tensor of shape (batch_size, seq_length, hidden_size)
        out, _ = self.lstm(x)  # out: tensor of shape (batch_size, seq_length, hidden_size)

        # 如果不导入h_s和h_c，默认每次都进行0初始化
        #  h_s和h_c表示每一个隐层的上一时间点输出值和输入细胞状态
        # h_s和h_c的格式均是(num_layers * num_directions, batch, HIDDEN_SIZE)
        # 如果是双向LSTM，num_directions是2，单向是1

        # Decode the hidden state of the last time step
        out = self.fc(out)
        return out

    
############################################

class conv_lstm(nn.Module):
    def __init__(self, input_size=113, hidden_size=130, num_layers=2, \
                 output_size=13, num_code=100,in_channel=1,bn=False):
        super(conv_lstm, self).__init__()
        self.conv = conv_swish(num_code,in_channel,bn)

        self.num_layers = num_layers
        self.num_code = num_code
        self.lstm = lstm(input_size, hidden_size, num_layers, \
                 output_size)
        
    def forward(self, k,ctrl):
        code=self.conv(k).unsqueeze(1).expand(k.shape[0],ctrl.shape[1],self.num_code)
        # for i in range(ctrl.shape[1]):
        #     k_ctrl[:,i]=torch.cat((ctrl[:,i],code),1)
        k_ctrl=torch.cat((ctrl,code),2)
        out = self.lstm(k_ctrl)  # out: tensor of shape (batch_size, seq_length, hidden_size)

        return out

    



class conv_lstm0(nn.Module):
    def __init__(self,nt, input_size=113, hidden_size=130, num_layers=2, \
                 fc_neuron=100,output_size=13, num_code=100,in_channel=1,bn=False):
        super(conv_lstm0, self).__init__()
        self.conv = conv_swish(num_code,in_channel,bn)

        self.num_layers = num_layers
        self.num_code = num_code
        self.lstm = lstm(input_size, hidden_size, num_layers, \
                 fc_neuron,output_size)
        self.input_size=input_size
        self.nt=nt
    def forward(self, k):
        code=self.conv(k).unsqueeze(1).expand(k.shape[0],self.nt,self.num_code)
        # code=torch.cat((ctrl,code),2)
        out = self.lstm(code)  # out: tensor of shape (batch_size, seq_length, hidden_size)

        return out
    



























