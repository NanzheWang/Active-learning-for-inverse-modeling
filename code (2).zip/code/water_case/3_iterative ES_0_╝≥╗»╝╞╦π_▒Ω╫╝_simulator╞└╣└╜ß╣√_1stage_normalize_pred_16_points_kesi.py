# -*- coding: utf-8 -*-
"""
Created on Wed Jun 15 06:32:36 2022

@author: WNZ
"""







import torch
import numpy as np
import matplotlib.pyplot as plt
import time
import scipy.io as scio
torch.manual_seed(100) 
import re
import os
import os.path
import operator
#import sys

from KLE import eigen_value_solution,sort_lamda,eigen_func
from forward_model_func_with_h_input_k1 import forward_model

from cnn_lstm import conv_lstm0,conv_lstm_ctrl,conv_lstm_ctrl_ae,lstm
plt.rcParams['figure.max_open_warning']=100
plt.rcParams['savefig.dpi'] = 100 #图片像素
plt.rcParams['figure.dpi'] = 100 #分辨率



######################################################################
##    注意： 网络输入顺序： T、 X、 Y
##    从矩阵中读取、写入数据顺序： T、 Y、 X
##
######################################################################


#########################################################################
#设备设置
device = torch.device('cuda:0')

###################################################################
#参数设置
###################################################################
Ne=100   #实现数

#渗透率场设置
mean_logk=0
var=1.0
L_x= 1220    #区域长度
L_y= 1220
domain=L_x*L_y
eta_x=L_x*0.4      #相关长度
eta_y=L_y*0.4      #相关长度

nx=61     #网格个数
ny=61
nz=1
nt=50      #时间步数

dx=20
dy=20
dz=20
dt=0.2

x=np.arange(1,nx+1,1)
x=x*dx
y=np.arange(1,ny+1,1)
y=y*dy


weight=0.85






num_ite=5
lamda=1000

lamda_set=[]

mis_set=[]


##############
#地层参数
ss=0.0001



#####################################
#########################################################
xp1=6
yp1=6

xp2=6
yp2=22

xp3=6
yp3=38

xp4=6
yp4=54

xp5=22
yp5=6

xp6=22
yp6=22

xp7=22
yp7=38

xp8=22
yp8=54

xp9=38
yp9=6

xp10=38
yp10=22

xp11=38
yp11=38

xp12=38
yp12=54

xp13=54
yp13=6

xp14=54
yp14=22

xp15=54
yp15=38

xp16=54
yp16=54

xp_set=[xp1,xp2,xp3,xp4,xp5,xp6,xp7,xp8,xp9,xp10,xp11,xp12,xp13,xp14,xp15,xp16]
yp_set=[yp1,yp2,yp3,yp4,yp5,yp6,yp7,yp8,yp9,yp10,yp11,yp12,yp13,yp14,yp15,yp16]
n_point=len(xp_set)

###########################################
###计算所需特征值个数
#########################################
n_test=50
lamda_x,w_x0,cumulate_lamda_x=eigen_value_solution(eta_x,L_x,var,n_test)
lamda_y,w_y0,cumulate_lamda_y=eigen_value_solution(eta_y,L_y,var,n_test)


############################################################
#二维特征值计算，混合，排序，截断
lamda_xy,w_x,w_y,n_eigen,cum_lamda=sort_lamda(lamda_x,w_x0,lamda_y,w_y0,domain,var,weight)

#########################################################
#根据weight获取所需计算特征值个数,并计算特征值以及特征函数值
#################################################
fn_x=[]
fn_y=[]


for i_x in range(nx):
    f_x=eigen_func(n_eigen,w_x,eta_x,L_x,x[i_x])
    fn_x.append([f_x,x[i_x]])
    
for i_y in range(ny):
    f_y=eigen_func(n_eigen,w_y,eta_y,L_y,y[i_y])
    fn_y.append([f_y,y[i_y]])

print('特征函数计算完成')




#############################################################
seed_r=500
#生成随机数，生成reference渗透率场实现
np.random.seed(seed_r)

kesi0=np.zeros((1,n_eigen))   #随机数数组
logk_r=np.zeros((1,nx,ny))       #渗透率场数组


for i_logk in range(1):
    kesi0[i_logk,:]=np.random.randn(n_eigen)   #随机数数组
    #由随机数计算渗透率场
    for i_x in range(nx):
        for i_y in range(ny):
            logk_r[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi0.transpose())



# logk_r=logk_r.transpose(0,2,1)-mean_logk
#渗透率场对数转化
k_r=np.exp(logk_r)

print('渗透率场实现生成完成')



########################################################################
#forward calculation

#修改工作目录
path = "../1_numerical_model/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()


hh_ref=forward_model(k_r,nt,nx,ny)

#2导入数据
#读取二进制文件npy
n_logk=500
n_logk_r=1
seed_n=100

hh_all=np.load('hh_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(n_logk,var,weight,seed_n))
# hh_ref=np.load('hh_ref_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(1,var,weight,seed_r))

h_seq_0=np.zeros((n_logk,nt,n_point))
for i in range(n_point):
    h_seq_0[:,:,i]=hh_all[:,:,xp_set[i],yp_set[i]]

h_seq_r=np.zeros((n_logk_r,nt,n_point))
for i in range(n_point):
    h_seq_r[:,:,i]=hh_ref[:,:,xp_set[i],yp_set[i]]



#################################################################################

h_seq_d=h_seq_0.min()
h_seq_u=h_seq_0.max()


h_seq_r_n=(h_seq_r-h_seq_d)/(h_seq_u-h_seq_d)


#！！！！！注意检查这里
obs1=h_seq_r_n.transpose(2,1,0).reshape(-1,1)
# obs1=h_seq_r.transpose(2,1,0).reshape(-1,1)

obs_true=obs1
n_obs=obs_true.shape[0]
d_std=0.01
#obs=obs_true+obs_true*d_std*np.random.randn(n_obs,1)
obs=obs_true+d_std*np.random.randn(n_obs,1)

C_d=np.eye(n_obs)*(d_std**2)



###################################################################
#实现生成
###################################################################
seed_initial=200
#生成随机数组，生成渗透率场实现
np.random.seed(seed_initial)

kesi=np.zeros((n_eigen,Ne))   #随机数数组
#kesi_mean_0=np.zeros((n_eigen,Ne))   #随机数数组

logk=np.zeros((Ne,nx,ny))       #渗透率场数组


for i_logk in range(Ne):
    kesi[:,i_logk]=np.random.randn(n_eigen)   #随机数数组
    #由随机数计算渗透率场
    for i_x in range(nx):
        for i_y in range(ny):
            logk[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi[:,i_logk:i_logk+1])

# kesi_0=kesi.copy()
logk_0=logk.copy()
# logk_0=logk.transpose(0,2,1)-mean_logk

#数据空间定义
k_0=np.exp(logk)


dd_pred=np.zeros((n_obs,Ne))
dd_pred2=np.zeros((n_obs,Ne))

print('渗透率场实现生成完成')




########################################################################
#forward calculation

#修改工作目录
path = "../1_numerical_model/"

# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)

# 修改当前工作目录
os.chdir( path )

# 查看修改后的工作目录
retval = os.getcwd()


# h_initial=forward_model(k_0,nt,nx,ny)


# ##################################################################################
# ##储存到二进制文件npy
# np.save('hh_initial_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(Ne,var,weight,seed_initial),h_initial)

#2导入数据
#读取二进制文件npy
h_initial=np.load('hh_test_data_nlogk=%d_var=%.2f_weight=%f_seed=%d.npy'%(Ne,var,weight,seed_initial))



####################################################################################################

logk_image=logk_0.reshape(Ne,1,nx,ny)
logk_col=logk_image.reshape(Ne,-1).transpose()

# logk_2=np.zeros((nx*ny,Ne))  
logk_2=np.zeros((Ne,nx,ny))       #渗透率场数组

kesi_2=np.zeros((n_eigen,Ne))   #随机数数组
kesi_1=kesi.copy()
###################################################################
#模型建立、载入
###################################################################
###########################################################################################

num_code=100
hidden_size=1000
num_hidden_layer=2
num_output=n_point
fc_neuron=100

net=conv_lstm0(nt,num_code,hidden_size,num_hidden_layer,fc_neuron,num_output,num_code,1).to(device)
#net=conv_lstm_ctrl_ae(nt,num_code+n_pro+n_inj,hidden_size,num_hidden_layer,fc_neuron,num_output,num_code,1).to(device)

#修改工作目录
path = "../3_network_parameter_results/"
# 查看当前工作目录
retval = os.getcwd()
print ("当前工作目录为 %s" % retval)
# 修改当前工作目录
os.chdir( path )
# 查看修改后的工作目录
retval = os.getcwd()
print ("目录修改成功 %s" % retval)

net.load_state_dict(torch.load('12_cnn_lstm_sample_ite_nlogk=210_seed_select=700_npoint=16_epoch=1000_batchsize=100_n_decay=10_t=695.996_t_sel=9.389.ckpt'))
net.to(device)
net.eval()
###################################################################
#预测，迭代更新
###################################################################

####迭代终止条件
delt1=0.1
delt2=0.001
ite_terminate=0
kesi_terminate=0
mis_terminate=0
lamda_terminate=0

def datamis(true,pred):
    mis=np.power((pred-true),2).sum()
    return mis


da_start=time.time()
for ite in range(num_ite):
    if ite==0:
        
        #预测
        start_time = time.time()
        
        
        
        logk_image = torch.from_numpy(logk_image)
        logk_image = logk_image.type(torch.FloatTensor)
        logk_image = logk_image.to(device)
        
        h_pred=net(logk_image)
        # h_pred=(h_pred*(h_seq_u-h_seq_d)+h_seq_d).cpu().detach().numpy()
        h_pred=h_pred.cpu().detach().numpy()
        
        
        col1=h_pred.transpose(2,1,0).reshape(-1,Ne)
        
        dd_pred=col1

        elapsed = time.time() - start_time                
        print('Prediction time: %.4f' % (elapsed))
    
        mis1=0
        for i_n in range(Ne):
            mis1=mis1+datamis(obs_true,dd_pred[:,i_n:i_n+1])  
        mis1=mis1/Ne/n_obs
        mis_set.append(mis1)
    
    #协方差矩阵计算
    

    c_kesi_d_all=np.cov(kesi_1,dd_pred)
    C_kesi_d=c_kesi_d_all[0:n_eigen,-n_obs:]
    C_dd=c_kesi_d_all[-n_obs:,-n_obs:]
    C_kesi=c_kesi_d_all[0:n_eigen,0:n_eigen]
    C_d_kesi=C_kesi_d.transpose() 
    if ite==0:
        C_kesi=np.eye((n_eigen))
        
    #更新
#    obs=obs_true+obs_true*d_std*np.random.randn(n_obs,1)
    for i in range(Ne): 
        obs=obs_true+d_std*np.random.randn(n_obs,1)
        inv_d=np.linalg.inv((1+lamda)*C_d+C_dd)
        
        C_kesi_d_inv_d=np.matmul(C_kesi_d,inv_d)
        delt_kesi=(1/(1+lamda))*np.matmul((C_kesi-np.matmul(C_kesi_d_inv_d,C_d_kesi)),(kesi_1[:,i:i+1]-kesi[:,i:i+1]))+\
                  np.matmul(C_kesi_d_inv_d,(dd_pred[:,i:i+1]-obs))
        kesi_2[:,i:i+1]=kesi_1[:,i:i+1]-delt_kesi
        # logk_image2=logk_2.transpose().reshape(Ne,1,nx,ny)
        
        #由随机数计算渗透率场
        for i_x in range(nx):
            for i_y in range(ny):
                logk_2[i,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_2[:,i:i+1])
    
        print('Updating realization %d at ite %d'%(i+1,ite+1))
    
    logk_image2=logk_2.reshape(Ne,1,nx,ny)

    
    lamda_set.append(lamda)
    #再次预测并对比效果
    
    start_time = time.time()
    logk_image2 = torch.from_numpy(logk_image2)
    logk_image2 = logk_image2.type(torch.FloatTensor)
    logk_image2 = logk_image2.to(device)
    
    h_pred=net(logk_image2)
    # h_pred=(h_pred*(h_seq_u-h_seq_d)+h_seq_d).cpu().detach().numpy()
    h_pred=h_pred.cpu().detach().numpy()      
        
    col1=h_pred.transpose(2,1,0).reshape(-1,Ne)
    
    dd_pred2=col1
                   
    elapsed = time.time() - start_time                
    print('Prediction time: %.4f' % (elapsed))  
    
    mis2=0
    for i_n in range(Ne):
        mis2=mis2+datamis(obs_true,dd_pred2[:,i_n:i_n+1])
    mis2=mis2/Ne/n_obs
    mis_set.append(mis2)
    

    if abs(kesi_2-kesi_1).max()<=delt1:
        kesi_terminate=1
    if ite==num_ite-1:
        ite_terminate=1
    
    if abs(mis2-mis1)/(max(1,abs(mis1)))<=delt2:
        mis_terminate=1


    if mis2<mis1:
        kesi_1=kesi_2.copy()
        dd_pred=dd_pred2.copy()
        mis1=mis2
        lamda=lamda/10
        if lamda<0.01:
            lamda=0.01
    else:
        lamda=lamda*10
        if lamda>1000000:
#            lamda=10000
            print('lamda大于100000！')
            lamda_terminate=1
#            sys.exit(0)

    if ite_terminate or kesi_terminate or mis_terminate or lamda_terminate:
        break
      

da_end=time.time()
da_time=da_end-da_start
print('DA time: %.4f' % (da_time)) 



            
#####################################################################
#输出参数

print('Iteration Number: %d'%(ite+1))
print('Maximun Ite limit: %d'%(num_ite))
print('d_error_std: %.3f'%(d_std))
print('Realization Number: %d'%(Ne)) 
print('Initial lamda:  %d'%(lamda_set[0]))

print('kesi limit error=%.5f'%(delt1))  
print('mis limit error=%.5f'%(delt2)) 
print('Terminate reason:')
if ite_terminate:
    print('Maximun iteration reached!')
elif kesi_terminate:
    print('|kesi2-kesi|<=%.5f'%(delt1))  
elif mis_terminate:
    print('|mis2-mis|/max(1,|mis1|)<=%.5f'%(delt2))  
elif lamda_terminate:
    print('lamda>100000!')
print('Mismatch:')    
print(np.array(mis_set).reshape(-1,1))
###################################################################
#评价指标计算
###################################################################

logk_final=np.zeros((Ne,nx,ny))
for i_logk in range(Ne):

    #由随机数计算渗透率场
    for i_x in range(nx):
        for i_y in range(ny):
            logk_final[i_logk,i_y,i_x]=mean_logk+np.sum(np.sqrt(lamda_xy)*fn_x[i_x][0]*fn_y[i_y][0]*kesi_1[:,i_logk:i_logk+1])


# logk_final=logk_final+mean_logk
# logk_r=logk_r+mean_logk
# logk_0=logk_0+mean_logk
logk_mean0=logk_0.mean(0)
logk_mean=logk_final.mean(0)

logk_std0=logk_0.std(0)
logk_std=logk_final.std(0)






#################################################
#计算RMSE
rmse=np.sqrt(np.power((logk_mean-logk_r),2).mean())
print('RMSE:  %.3f'%(rmse))

rmse_0=np.sqrt(np.power((logk_mean0-logk_r),2).mean())
print('RMSE:  %.3f'%(rmse_0))



k_final=np.exp(logk_final)


# fitting_plot=True
fitting_plot=False
if fitting_plot:
    #数据空间定义

    pp_final=np.zeros((Ne,nt+1,nx,ny))
    ss_final=np.zeros((Ne,nt+1,nx,ny))
    qo_array_final=np.zeros((nt+1,n_well_inj,Ne))
    qw_array_final=np.zeros((nt+1,n_well_pro,Ne))
    iw_array_final=np.zeros((nt+1,n_well_inj,Ne))    
    simu_start=time.time()
    ########################################################################
    #forward calculation
    #修改工作目录
    path = "../"
    
    # 查看当前工作目录
    retval = os.getcwd()
    print ("当前工作目录为 %s" % retval)
    
    # 修改当前工作目录
    os.chdir( path )
    
    # 查看修改后的工作目录
    retval = os.getcwd()
    
    print ("目录修改成功 %s" % retval)
    
    
    pp_final,ss_final,wopr_final,wwir_final,wwpr_final=run_rel(nx,ny,nz,nt0,Ne,k_final)
    
    qo_array_final=wopr_final[1:]
    qw_array_final=wwpr_final[1:]
    iw_array_final=wwir_final[1:] 
    
    simu_end=time.time()
    simu_time=simu_end-simu_start
    print('Simulation time: %.4f' % (simu_time)) 
    
    
    
    ########################################################################
    #################################################################################
    #切换工作目录
    # os.chdir( "../" )
    # path = "\\2_data\\"
    
    # # 查看当前工作目录
    # now = os.getcwd()
    # print ("当前工作目录为 %s" % now)
    
    # # 修改当前工作目录
    # os.chdir( now+path )
    
    # # 查看修改后的工作目录
    # new_path = os.getcwd()
    # print ("目录修改成功 %s" % new_path)
    #
    #
    
    
    d1_final_sim=qo_array_final[:,0,:]
    d2_final_sim=qo_array_final[:,1,:]
    d3_final_sim=qo_array_final[:,2,:]
    d4_final_sim=qo_array_final[:,3,:]
    d5_final_sim=qo_array_final[:,4,:]
    
    
    d1_0_sim=qo_array_0_all[:,0,:]
    d2_0_sim=qo_array_0_all[:,1,:]
    d3_0_sim=qo_array_0_all[:,2,:]
    d4_0_sim=qo_array_0_all[:,3,:]
    d5_0_sim=qo_array_0_all[:,4,:]

    d1_final_sim_w=qw_array_final[:,0,:]
    d2_final_sim_w=qw_array_final[:,1,:]
    d3_final_sim_w=qw_array_final[:,2,:]
    d4_final_sim_w=qw_array_final[:,3,:]
    d5_final_sim_w=qw_array_final[:,4,:]
    
    
    d1_0_sim_w=qw_array_0_all[:,0,:]
    d2_0_sim_w=qw_array_0_all[:,1,:]
    d3_0_sim_w=qw_array_0_all[:,2,:]
    d4_0_sim_w=qw_array_0_all[:,3,:]
    d5_0_sim_w=qw_array_0_all[:,4,:]

    d1_final_sim_i=iw_array_final[:,0,:]
    d2_final_sim_i=iw_array_final[:,1,:]
    d3_final_sim_i=iw_array_final[:,2,:]
    d4_final_sim_i=iw_array_final[:,3,:]
    # d5_final_sim_i=iw_array_final[:,4,:]
    
    
    d1_0_sim_i=iw_array_0_all[:,0,:]
    d2_0_sim_i=iw_array_0_all[:,1,:]
    d3_0_sim_i=iw_array_0_all[:,2,:]
    d4_0_sim_i=iw_array_0_all[:,3,:]
    # d5_0_sim_i=iw_array_0[:,4,:]    
    ###################################################################
    #结果展示
    ###################################################################
    t0=np.linspace(1,nt0,nt0)

    line = np.linspace(-50, 2000, 2)[:,None]
    
    ##oil production   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d1_0_sim[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,0,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    plt.plot(t0,qo_array_all[:,0,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d1_final_sim[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs1, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    plt.title("Results for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d2_0_sim[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,1,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    plt.plot(t0,qo_array_all[:,1,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d2_final_sim[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs2, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d3_0_sim[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,2,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    plt.plot(t0,qo_array_all[:,2,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d3_final_sim[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs3, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    

    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d4_0_sim[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,3,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    plt.plot(t0,qo_array_all[:,3,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d4_final_sim[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs4, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d5_0_sim[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,4,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    plt.plot(t0,qo_array_all[:,4,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d5_final_sim[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs5, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
   
    
   
    
   
    
    ##water production   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d1_0_sim_w[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,0,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    plt.plot(t0,qw_array_all[:,0,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d1_final_sim_w[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs1, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    plt.title("Results for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d2_0_sim_w[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,1,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    plt.plot(t0,qw_array_all[:,1,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d2_final_sim_w[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs2, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d3_0_sim_w[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,2,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    plt.plot(t0,qw_array_all[:,2,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d3_final_sim_w[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs3, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d4_0_sim_w[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,3,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    plt.plot(t0,qw_array_all[:,3,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d4_final_sim_w[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs4, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d5_0_sim_w[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,4,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    plt.plot(t0,qw_array_all[:,4,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d5_final_sim_w[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs5, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    
    

    ##water injection   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d1_0_sim_i[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,0,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for INJ 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    plt.plot(t0,iw_array_all[:,0,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d1_final_sim_i[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs1, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    plt.title("Results for INJ 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d2_0_sim_i[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,1,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for INJ 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    plt.plot(t0,iw_array_all[:,1,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d2_final_sim_i[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs2, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for INJ 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d3_0_sim_i[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,2,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for INJ 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    plt.plot(t0,iw_array_all[:,2,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d3_final_sim_i[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs3, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for INJ 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0,d4_0_sim_i[:,i], 'k-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,3,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for INJ 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    plt.plot(t0,iw_array_all[:,3,0], 'r-', linewidth =3)
    for i in range(Ne):
        plt.plot(t0,d4_final_sim_i[:,i], 'k-', linewidth = 0.5)
    # plt.plot(t0,obs4, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for INJ 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
k_g=0
if k_g:
    ##oil production   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d1_0_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d1_0_sim[nt:nt0,i], 'grey', linestyle='-',linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,0,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d1_final_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d1_final_sim[nt:nt0:,i], 'grey', linestyle='-', linewidth = 0.5)
    # plt.plot(t0,obs1, 'r-', linewidth =3)
    plt.plot(t0,qo_array_all[:,0,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    plt.title("Results for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d2_0_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d2_0_sim[nt:nt0,i],'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,1,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d2_final_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d2_final_sim[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,1,0], 'r-', linewidth =3)
    # plt.plot(t0,obs2, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d3_0_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d3_0_sim[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,2,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d3_final_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d3_final_sim[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,2,0], 'r-', linewidth =3)
    # plt.plot(t0,obs3, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    

    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d4_0_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d4_0_sim[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,3,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d4_final_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d4_final_sim[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,3,0], 'r-', linewidth =3)
    # plt.plot(t0,obs4, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d5_0_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d5_0_sim[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,4,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Oil production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d5_final_sim[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d5_final_sim[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qo_array_all[:,4,0], 'r-', linewidth =3)
    # plt.plot(t0,obs5, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1250)
   
    
   
    
   
    
    ##water production   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d1_0_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d1_0_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,0,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d1_final_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d1_final_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,0,0], 'r-', linewidth =3)
    # plt.plot(t0,obs1, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    plt.title("Results for PRO 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d2_0_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d2_0_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,1,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d2_final_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d2_final_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,1,0], 'r-', linewidth =3)
    # plt.plot(t0,obs2, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d3_0_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d3_0_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,2,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d3_final_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d3_final_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,2,0], 'r-', linewidth =3)
    # plt.plot(t0,obs3, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d4_0_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d4_0_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,3,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d4_final_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d4_final_sim_w[nt:nt0,i],  'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,3,0], 'r-', linewidth =3)
    # plt.plot(t0,obs4, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d5_0_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d5_0_sim_w[nt:nt0,i],  'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,4,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water production \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d5_final_sim_w[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d5_final_sim_w[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,qw_array_all[:,4,0], 'r-', linewidth =3)
    # plt.plot(t0,obs5, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for PRO 5",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1000)
    
    
    
    
    

    ##water injection   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d1_0_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d1_0_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,0,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for INJ 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d1_final_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d1_final_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,0,0], 'r-', linewidth =3)
    # plt.plot(t0,obs1, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    plt.title("Results for INJ 1",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d2_0_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d2_0_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,1,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    plt.title("Initial states for INJ 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d2_final_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d2_final_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,1,0], 'r-', linewidth =3)
    # plt.plot(t0,obs2, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for INJ 2",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    
    
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d3_0_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d3_0_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,2,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for INJ 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d3_final_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d3_final_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,2,0], 'r-', linewidth =3)
    # plt.plot(t0,obs3, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for INJ 3",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
   
    plt.figure(figsize=(8,3))
    plt.subplot(121)
    for i in range(Ne):
        plt.plot(t0[0:nt],d4_0_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d4_0_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,3,0], 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    plt.ylabel('Water injection \n rate (m$^3$/day)',fontsize=15)
    # plt.ylim(199.8,202)
    plt.title("Initial states for INJ 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    plt.subplot(122)
    for i in range(Ne):
        plt.plot(t0[0:nt],d4_final_sim_i[0:nt,i], 'k-', linewidth = 0.5)
        plt.plot(t0[nt:nt0],d4_final_sim_i[nt:nt0,i], 'grey', linestyle='-', linewidth = 0.5)
    plt.plot(t0,iw_array_all[:,3,0], 'r-', linewidth =3)
    # plt.plot(t0,obs4, 'r-', linewidth =3)
    plt.plot(t0[nt-1]*np.ones((2,1)),line, 'b--', linewidth = 2)
    plt.xlabel('Time (day)',fontsize=15)
    #plt.ylabel('Oil production \n rate (m$^3$/day)')
    # plt.ylim(199.8,202)
    plt.title("Results for INJ 4",fontsize=13)
    plt.tick_params(labelsize=12)
    plt.ylim(0,1500)
    
    
    
    


##########################################################
#################################
#渗透率场绘制
plt.figure(figsize=(13.5,3))
plt.subplot(131)
plt.imshow(logk_r[0], origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
           extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
plt.xlabel('$x$',fontsize=15)
plt.ylabel('$y$',fontsize=15)
plt.tick_params(labelsize=12)
# plt.yticks(np.linspace(500,2000,4))
plt.title('Reference',fontsize=15)
cbar=plt.colorbar()
# cbar.set_ticks(np.linspace(2.4,3.6,7))


plt.subplot(132)
plt.imshow(logk_mean0, origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
           extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
plt.xlabel('$x$',fontsize=15)
#plt.ylabel('y')
plt.tick_params(labelsize=12)
# plt.yticks(np.linspace(500,2000,4))
plt.title('Initial mean',fontsize=15)
cbar=plt.colorbar()
# cbar.set_ticks(np.linspace(2.4,3.6,7))


plt.subplot(133)
plt.imshow(logk_mean, origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
           extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
plt.xlabel('$x$',fontsize=15)
#plt.ylabel('y')
plt.tick_params(labelsize=12)
# plt.yticks(np.linspace(500,2000,4))
plt.title('Final mean',fontsize=15)
cbar=plt.colorbar()
# cbar.set_ticks(np.linspace(2.4,3.6,7))

#plt.subplots_adjust(bottom=0.1, right=0.8, top=0.9)
#cax = plt.axes([0.82, 0.1, 0.02, 0.8])
#plt.colorbar(cax=cax)
##############################################################################################
plt.figure(figsize=(8.5,3))
plt.subplot(121)
plt.imshow(logk_mean0, origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
           extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
plt.xlabel('$x$',fontsize=15)
plt.ylabel('$y$',fontsize=15)
plt.tick_params(labelsize=12)
plt.title('Initial mean',fontsize=15)
cbar=plt.colorbar()
# cbar.set_ticks(np.linspace(2.4,3.6,7))
plt.yticks(np.linspace(300,1200,4))
plt.xticks(np.linspace(300,1200,4))

plt.subplot(122)
plt.imshow(logk_mean, origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
           extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
plt.xlabel('$x$',fontsize=15)
#plt.ylabel('y')
plt.tick_params(labelsize=12)
plt.title('Final mean',fontsize=15)
cbar=plt.colorbar()
# cbar.set_ticks(np.linspace(2.4,3.6,7))
plt.yticks(np.linspace(300,1200,4))
plt.xticks(np.linspace(300,1200,4))

#plt.subplots_adjust(bottom=0.1, right=0.8, top=0.9)
#cax = plt.axes([0.82, 0.1, 0.02, 0.8])
#plt.colorbar(cax=cax)

##############################################################################################
plt.figure(figsize=(8.5,3))
plt.subplot(121)
plt.imshow(logk_std0, origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
           extent=[x.min(), x.max(), y.min(),y.max()],vmin=0,vmax=1.5)
plt.xlabel('$x$',fontsize=15)
plt.ylabel('$y$',fontsize=15)
plt.tick_params(labelsize=12)
plt.title('Initial std',fontsize=15)
cbar=plt.colorbar()
#cbar.set_ticks(np.linspace(200,202,5))
plt.yticks(np.linspace(300,1200,4))
plt.xticks(np.linspace(300,1200,4))

plt.subplot(122)
plt.imshow(logk_std, origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
           extent=[x.min(), x.max(), y.min(),y.max()],vmin=0,vmax=1.5)
plt.xlabel('$x$',fontsize=15)
#plt.ylabel('y')
plt.tick_params(labelsize=12)
plt.title('Final std',fontsize=15)
cbar=plt.colorbar()
#cbar.set_ticks(np.linspace(200,202,5))
plt.yticks(np.linspace(300,1200,4))
plt.xticks(np.linspace(300,1200,4))

#plt.subplots_adjust(bottom=0.1, right=0.8, top=0.9)
#cax = plt.axes([0.82, 0.1, 0.02, 0.8])
#plt.colorbar(cax=cax)

for i in range(5):
    plt.figure(figsize=(5,3))
    plt.imshow(logk_final[i], origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
               extent=[x.min(), x.max(), y.min(),y.max()])
    plt.xlabel('$x$',fontsize=15)
    #plt.ylabel('y')
    plt.tick_params(labelsize=12)
    # plt.yticks(np.linspace(500,2000,4))
    # plt.title('Final mean',fontsize=15)
    cbar=plt.colorbar()
####################################################################
####################################################################
#选取点的位置

# plt.figure(figsize=(5,5))

# for i in range(n_point):
#     plt.scatter(xp[i],yp[i],marker='*',color='k')
#     plt.text(xp[i],yp[i],'Point %d'%(i+1),fontsize=10)
# plt.xlabel('x',fontsize=15)
# plt.ylabel('y',fontsize=15)
# plt.title('Points Location',fontsize=15)
# plt.xlim(0,L_x)
# plt.ylim(0,L_y)
# plt.tick_params(labelsize=12)
##############################
#lamda趋势变化
plt.figure(figsize=(3.5,3.5))
plt.plot(range(len(lamda_set)),lamda_set)
plt.xlabel('Ite',fontsize=15)
plt.ylabel('Lamda',fontsize=15)

#mis-match趋势变化
plt.figure(figsize=(3.5,3.5))
plt.plot(range(len(mis_set)),mis_set)
plt.xlabel('Ite',fontsize=15)
plt.ylabel('Mismatch',fontsize=15)





####################################################################
#选取点的位置
x_ticks=np.arange(300,1220,300)
plt.figure(figsize=(5,5))
mm1=plt.imshow(logk_r[0], origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
                          extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
cb=plt.colorbar(mm1,fraction=0.046, pad=0.04)
# for i in range(n_point):
#     plt.scatter(xp[i],yp[i],marker='^',color='k')
#     plt.text(xp[i],yp[i],'PRO %d'%(i+1),fontsize=12,color='k',verticalalignment='bottom',\
#              horizontalalignment='center',weight='medium')
plt.xlabel('x (m)',fontsize=18)
plt.ylabel('y (m)',fontsize=18)
plt.tick_params(labelsize=15)
plt.xticks(x_ticks,fontsize=15)
plt.yticks(x_ticks,fontsize=15)
cb.ax.tick_params(labelsize=12)

#选取点的位置
x_ticks=np.arange(300,1220,300)
plt.figure(figsize=(5,5))
# mm1=plt.imshow(logk_r[0], origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
#                           extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
mm1=plt.contourf(logk_r[0],14, origin='lower',cmap='jet',interpolation='nearest',aspect='equal',
                             extent=[x.min(), x.max(), y.min(),y.max()],vmin=-2,vmax=2)
cb=plt.colorbar(mm1,fraction=0.05, pad=0.04)
plt.xlabel('x (m)',fontsize=18)
plt.ylabel('y (m)',fontsize=18)
plt.tick_params(labelsize=15)
plt.xticks(x_ticks,fontsize=15)
plt.yticks(x_ticks,fontsize=15)
cb.ax.tick_params(labelsize=12)
cb.set_clim( -2, 2 )



# #修改工作目录
# path = "../2_results_data/"

# # 查看当前工作目录
# retval = os.getcwd()
# print ("当前工作目录为 %s" % retval)

# # 修改当前工作目录
# os.chdir( path )

# # 查看修改后的工作目录
# retval = os.getcwd()

# # #2存入数据
# # logk_final=logk_final.transpose(0,2,1)
# # k_final=np.exp(logk_final)
# # data_k = 'k_ne=%d_mean=%.2f_var=%.2f_seed=%d_dstd=%.2f_ite=%d_rmse=%.3f.mat'%(Ne,mean_logk,var,seed_n,d_std,ite+1,rmse)
# # scio.savemat(data_k, {'k_set':k_final})

# # data_logk = 'logk_ne=%d_mean=%.2f_var=%.2f_seed=%d_dstd=%.2f_ite=%d_rmse=%.3f.mat'%(Ne,mean_logk,var,seed_n,d_std,ite+1,rmse)
# # scio.savemat(data_logk, {'logk_set':logk_final})

# np.save('lnK_final_N=%d_rmse=%.3f_t=%.3f.npy'%(Ne,rmse,da_time),logk_final)


# np.save('lnK_0_N=%d.npy'%(Ne),logk_0)





