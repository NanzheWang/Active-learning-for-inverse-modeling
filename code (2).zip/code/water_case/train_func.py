# -*- coding: utf-8 -*-
"""
Created on Mon Jun 20 06:04:54 2022

@author: WNZ
"""



import torch
import torch.nn as nn
import torch.nn.functional as func
import random
import scipy.io as scio
torch.manual_seed(100) 
import math
import numpy as np
import time


def train_model(net,train_in,train_out,num_epoch,LR,batchsize,device):
    
    
    train_in= torch.from_numpy(train_in)
    train_in= train_in.type(torch.FloatTensor)
    
    train_out= torch.from_numpy(train_out)
    train_out= train_out.type(torch.FloatTensor)
    
    
    n_train=len(train_out)

    
    N_batch=math.ceil(n_train/batchsize )
    
    k_train_set=[]
    out_train_set=[]

    
    for i_batch in range(int(N_batch)):
        k_train_set.append(train_in[batchsize*i_batch:batchsize*(i_batch+1)])
        out_train_set.append(train_out[batchsize*i_batch:batchsize*(i_batch+1)])
        
    # 定义神经网络优化器

    
    optimizer=torch.optim.Adam([
        {'params': net.parameters()},   
        # {'params': Net_s.parameters()},   
    # ],lr=LR,weight_decay=0.005)
    ],lr=LR) 



    lr_list=[]
    
    #定义loss数组
    loss_set=[]
    f1_set=[]
    f2_set=[]

    
    n_decay=10

    start_time = time.time()  
    ##########################################################################
    ##分批训练
    for epoch in range(num_epoch):   # 训练所有!整套!数据 3 次
        for ite in range(N_batch):
            batch_k=k_train_set[ite].to(device)
            batch_y=out_train_set[ite].to(device)
            
        
            optimizer.zero_grad()
            h_pred=net(batch_k)
            
            
            f1=torch.pow((h_pred-batch_y),2).mean()
    
            loss=f1
            loss.backward()
            optimizer.step()        
            loss=loss.data
            f1=f1.data
    
            loss_set.append(loss)
            f1_set.append(f1)
    
            print('Epoch: ', epoch, '| Step: ', ite, '|loss: ',loss)
            lr_list.append(optimizer.state_dict()['param_groups'][0]['lr'])
    
        if (epoch+1) % n_decay == 0 and optimizer.state_dict()['param_groups'][0]['lr']>0.00005:
            for p in optimizer.param_groups:
                p['lr'] *= 0.9
    
    
    end_time = time.time() 
    
    training_time = end_time  - start_time                
    print('Training time: %.4f' % (training_time))

    return net,training_time
































































